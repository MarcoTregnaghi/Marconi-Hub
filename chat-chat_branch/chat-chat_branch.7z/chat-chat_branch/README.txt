Idead Hub è una WebApp costruita con i framework Bootstrap e NodeJS.
Permette di chattare tra utenti in locale che si sono registrati e loggati. sdfsdf

Per lanciare lo script server.js e poter quindi avviare l'applicazione è necessario prima
installare NodeJS e dopodichè tutte le dipendenze tramite il comando npm i.

Una volta fatto ciò avviare tramite il comando "npm start" che è l'equivalente di "node server.js".

Per collegarsi basterà immettere nella URL di qualsiasi browser il proprio IP della macchina che sta
eseguendo server.js aggiungendo ":3000" alla fine(es. 192.168.1.112:3000).

Il server esporrà i primi tre file: un html, un css e uno script js.

L'utente dovrà registrarsi se non ancora fatto e poi una volta loggato Il server esporrà altri tre file:
un html, un css e uno script js e finalmente si potrà usufruire di tutti i servizi:
cercare un utente, inviare una richiesta di amicizia per chattare e cosa più fondamentale, chattare.

L'app è in continuo aggiornamento, per visitare il repository github: https://github.com/MarcoTregnaghi/chat/tree/chat_branch

Author: Tregnaghi Marco.